
(function() {
    if (window.__glabs_interceptor_installed) return;
    window.__glabs_interceptor_installed = true;

    function saveIfClean(fn) {
        if (!fn || typeof fn !== 'function') return;
        if (window.__real_execute) return;
        try {
            const str = fn.toString();
            if (!str.includes('extension_hijack_detected')) {
                window.__real_execute = fn;
            }
        } catch (e) {}
    }

    const origDef = Object.defineProperty;
    Object.defineProperty = function(obj, prop, desc) {
        if (prop === 'execute') {
            if (obj && obj.execute) saveIfClean(obj.execute);
            if (desc && typeof desc.value === 'function') saveIfClean(desc.value);
        }
        return origDef.apply(this, arguments);
    };

    let timer = setInterval(() => {
        if (window.grecaptcha && window.grecaptcha.enterprise && window.grecaptcha.enterprise.execute) {
            saveIfClean(window.grecaptcha.enterprise.execute);
        }
    }, 5);
    setTimeout(() => { if (timer) clearInterval(timer); }, 20000);
})();
